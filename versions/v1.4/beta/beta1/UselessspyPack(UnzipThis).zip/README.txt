Official Uselessspy Pack by Zird

!!! YOU NEED TO USE OPTIFINE !!!

When you have unzipped the parent folder of this README.txt file place the folder called "§f§kO§k§6 UselessSpy Texture Pack §f§kO§k§3" into your 'resourcepack' folder in minecraft

That should work, if you have problems ask Zird#5088 on discord


- 15.06.2023
- Zird