To use the pack you will need:

	1. Optifine for the desired version
	2. And to put the texture pack file in your "ResourcePack" folder

IF you don't know how to put a texture pack file in your resources packs, then go look online



- zird uwu